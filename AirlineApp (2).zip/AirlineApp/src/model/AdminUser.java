package model;

public class AdminUser extends User {
    public AdminUser(String login, String password) {
        super(login, password);
    }
}
