package model;

public class RegularUser extends User {
    public RegularUser(String login, String password) {
        super(login, password);
    }
}
